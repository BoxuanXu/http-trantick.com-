<?php	
header("Content-Type:text/html; charset=utf-8"); 
define('APP_ROOT', str_replace('\\', '/', dirname(__FILE__))); 

 
$conn=mysql_connect('localhost','root','676892') or die("error connecting") ; //连接数据库
 
mysql_query("set character set 'utf8'"); //数据库输出编码 应该与你的数据库编码保持一致.南昌网站建设公司百恒网络PHP工程师建议用UTF-8 国际标准编码.
 
mysql_select_db('Spider_Quene'); //打开数据库
 
$sql ="select * from Persioninfo"; //SQL语句
 
$result = mysql_query($sql,$conn); //查询

$i=1;
$content ="";
//$all_keywords = array();
//$all_weight = array();

$sql_truncate = "truncate table state_keywords";
mysql_query($sql_truncate);


while($row = mysql_fetch_array($result))
{
	
	if(strlen($content) < 1024 * 1024)
	{
		$content .= $row['address'];
		$content = preg_replace('/\s+/','',$content);
		$content = str_replace('span','',$content);
		$content = str_replace('没有','',$content);
		$content = str_replace('内容','',$content);
		$content = str_replace('显示','',$content);
		$content = str_replace(' ','',$content);
	}
	else
	{
		$words = get_tags_arr($content);
		foreach($words as $val)
		{
			$sql2 = "select * from state_keywords where keyword='";
			$sql2 .= $val['word'];		
			$sql2 .="'";
			$result2 = mysql_query($sql2,$conn);
			$sql3 = "";
			if($row2 = mysql_fetch_array($result2))
			{
				 $times = $val['times'] + $row2['times'];
				 $weight = ($val['weight'] + $row2['weight']) / 2;
				 $sql3 = "update state_keywords set times='";
				 $sql3 .=$times;
				 $sql3 .="',weight='";
				 $sql3 .= $weight;
				  $sql3 .= "' where keyword='";
				 $sql3 .= $val['word'];
				 $sql3 .= "'";
				 
			}
			else
			{
				$sql3 = "insert into state_keywords values(NULL,'";
				$sql3 .= $val['word'];
				$sql3 .= "',";
				$sql3 .= $val['times'];
				$sql3 .= ",";
				$sql3 .= $val['weight'];
				$sql3 .= ",Now())";
			}
			mysql_query($sql3);
	//		$all_keywords[$val['word']]=$all_keywords[$val['word']] + $val['times'];
	//		$all_weight[$val['word']]=$all_weight[$val['word']] + $val['weight'];
							
		}
		print_r($i);
		
		echo PHP_EOL;
		$content="";
	}
	$i++;
} 
//echo '<p>'.$all_content.'</p>';

//$test = '这里是一段中文测试代码!'; 
function get_tags_arr($title) 
{ 
//require(APP_ROOT.'/pscws4.class.php'); 
//$pscws = new PSCWS4(); 
 $so = scws_new();
 $so->set_charset('utf-8');
 $so->add_dict(ini_get('scws.default.fpath') . '/dict.utf8.xdb');
 $so->set_rule(ini_get('scws.default.fpath') . '/rules.utf8.ini');
 $so->set_ignore(true);
 $so->set_multi(false);
//$pscws->set_dict(APP_ROOT.'/scws/dict.utf8.xdb'); 
//$pscws->set_rule(APP_ROOT.'/scws/rules.utf8.ini'); 
//$pscws->set_ignore(true); 
//$pscws->send_text($title); 
//$words = $pscws->get_tops(5); 
$so->set_duality(false);
$so->send_text($title);
$words = $so->get_tops(30);
/*$tags = array(); 
foreach ($words as $val) { 
$tags[] = $val['word']; 
} 
$so->close();
//$pscws->close(); 
return $tags; */
return $words;
}


/*for($i=1;$i<sizeof($all_keywords);$i++)
{
	$sql = "insert into state_keywords values(NULL,'$all_keywords[$i]','$all_weight[$i]',Now())"; 
	mysql_query($sql);
}*/
mysql_close();
?>
